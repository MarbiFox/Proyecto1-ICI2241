package com.mycompany.ventana;

import java.util.HashMap;

public class MapaCiudades {
    private HashMap <String,Ciudad> mapaCiudades;
    
    public MapaCiudades(){
        mapaCiudades = new HashMap();
    }
    
    public Ciudad get_ciudad(String name) throws UnvalidCityException {
        if (mapaCiudades.get(name) == null){
            throw new UnvalidCityException();
        }
        return mapaCiudades.get(name);
    }
    
    public void setObject(String n,Ciudad temp){
        mapaCiudades.put(n, temp);
    }
    
    public Ciudad searchObject(String n){
        return mapaCiudades.get(n);
    }
    
    public void addCity (String text, Ciudad city) {
        //Agregar ciudad a Mapa de Ciudades.
        mapaCiudades.put(text, city);
    }
    
    public void deleteCity (String text, Ciudad city) {
        //Eliminar Ciudad.
        mapaCiudades.remove(text, city);
    }
    
    public void clean () {
        mapaCiudades.clear();
    }
    
}