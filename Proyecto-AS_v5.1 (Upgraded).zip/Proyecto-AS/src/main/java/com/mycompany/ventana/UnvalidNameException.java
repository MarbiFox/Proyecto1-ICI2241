
package com.mycompany.ventana;

public class UnvalidNameException extends Exception {
    public UnvalidNameException (){
        super("El nombre escogido para la ciudad no es válido.");
    }
}
