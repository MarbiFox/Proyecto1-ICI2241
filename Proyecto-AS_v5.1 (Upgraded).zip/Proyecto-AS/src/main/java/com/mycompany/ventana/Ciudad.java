package com.mycompany.ventana;

import java.io.FileNotFoundException;

public class Ciudad {
    //Variables de instancia
    
    private String nombre; //ciudad de partida
    private ListaBuses buses;
    
    //----Constructor----  
    /*Crea una ciudad con un nombre e inicializa el ArrayList*/
    public Ciudad(String n){
        nombre = n;
        buses = new ListaBuses();
    }
    
    public Ciudad(){
        nombre = "";
        buses = new ListaBuses();
    }
       
    //----Metodos----
    
    //----Setter----
    /*Modifica el nombre de la ciudad*/
    public void set_nombre(String n){
        this.nombre = n;
    }
    
    //----Getter----
    /*Obtiene el nombre de la ciudad*/
    public String get_nombre(){
        return this.nombre;
    }
    
    public int getSizeArrayList(){
        return this.buses.get_size();
    }
    
    public Bus get_bus(int i){
        return (Bus)buses.get_i(i);
    }
    
    /*Agrega un nuevo elemento a la ArrayList*/
    public void agregarBus(Bus p){
        buses.addBus(p);
    }

    public void agregarBus(Bus p,int valor_actual){
        buses.addBus(p);
    }
    
    public Bus buscarBus (int id) {
        for (int i = 0; i < buses.get_size(); i++) {
            if (buses.get_i(i).get_ID() == id) {
                return buses.get_i(i);
            }
        }
        return null;
    }
    
    public Bus buscarBus (String destino) {
        for (int i = 0; i < buses.get_size(); i++) {
            if (buses.get_i(i).get_destino().equals(destino)) {
                return buses.get_i(i);
            }
        }
        return null;
    }
    
    public int contarViajes (String destino) {
        int cont = 0;
        for (int i = 0; i < buses.get_size(); i++) {
            if (buses.get_i(i).get_destino().equals(destino)) {
                cont++;
            }
        }
        return cont;
    }
    
    //Eliminar Bus
    public void eliminarBus(int ID){
        boolean valor = false;
        for(int i = 0;i < buses.get_size();i++){
            Bus b = buses.get_getter(i);
            if(b.get_ID() == ID){
                buses.deleteBus(b);
                valor = true;
            }
        }
        if (valor == false)
            System.out.println("Bus no encontrado");
    }
    
    public void importar() throws FileNotFoundException{
        buses.importar(this.nombre);
    }
    
}
