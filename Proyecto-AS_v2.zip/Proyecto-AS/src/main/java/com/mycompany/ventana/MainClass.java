
package com.mycompany.ventana;
import java.io.IOException;
import javax.swing.DefaultListModel;


public class MainClass {
    public static void main (String [] args) throws IOException {
        System.out.println("Ola que ase...");
        //Iniciar Empresa
        Empresa e = new Empresa ();
        e.run(e);
    }
    
    public static void printAlgo() {
        System.out.println("Print");
    }
    
    public static void addCity (DefaultListModel cityModel, String text) throws UnvalidNameException {
        //Verificar Excepción
        if (text.length() > 12 || text.length() < 3) {
            throw new UnvalidNameException(); 
        }
        //Crear nueva Ciudad a partir del texto
        Ciudad city = new Ciudad (text);
        //Agregar ciudad a Lista y Mapa de Ciudades.
        ListaCiudades.addCity(text);
        //Agregar el nombre de la ciudad al cityModel
        cityModel.addElement(city.get_nombre());
    }
    
    
    public static void initializeMenu(int x, int y) {
        System.out.println("Menú");
        VentanaInicial screenMenu = new VentanaInicial();
        screenMenu.setDefaultCloseOperation(VentanaInicial.DISPOSE_ON_CLOSE);
        screenMenu.setSize(800, 500);
        screenMenu.setLocationRelativeTo(null);

        screenMenu.setVisible(true);
        screenMenu.setLocation(x, y);
        System.out.println("x:" + x + " y:" + y);
        
        
    }
    
}
