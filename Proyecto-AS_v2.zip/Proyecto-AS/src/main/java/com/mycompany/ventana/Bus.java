package com.mycompany.ventana;

public class Bus {
    //Variables de instancia
    private int ID;
    private String inicio;
    private String destino;
    private String fecha;
    private int costo;
    private int num_asientos;
    
    //----Constructor----  
    public Bus(int ID, String inicio, String destino, String fecha, int costo, int num_asientos){
        this.ID = ID;
        this.inicio = inicio;
        this.destino = destino;
        this.fecha = fecha;
        this.costo = costo;
        this.num_asientos = num_asientos;       
    }
    
    public Bus(String ID, String inicio, String destino, String fecha, String costo, String num_asientos){
        this.ID = Integer.parseInt(ID);
        this.inicio = inicio;
        this.destino = destino;
        this.fecha = fecha;
        this.costo = Integer.parseInt(costo);
        this.num_asientos = Integer.parseInt(num_asientos);       
    }
    
    //----Metodos----
        
    //---Getter----
    public int get_ID(){
        return this.ID;
    }
    
    public String get_destino(){
        return this.destino;
    }
    
    public String get_inicio(){
        return this.inicio;
    }
    
    public String get_fecha(){
        return this.fecha;
    }
    
    public int get_costo(){
        return this.costo;
    }
    
    public int get_numAsientos(){
        return this.num_asientos;
    }
    
    //----Setter----
    
    public void set_ID(int ID){
        this.ID = ID;
    }
    
    public void set_inicio(String inicio){
        this.inicio = inicio;
    }
       
    public void set_destino(String destino){
        this.destino = destino;
    }
    
    public void set_fecha(String fecha){
        this.fecha = fecha;
    }
    
    public void set_costo(int costo){
        this.costo = costo;
    }
    
    public void set_numAsientos(int num_asientos){
        this.num_asientos = num_asientos;
    }
    
    public void mostrar_informacion_bus(){
        System.out.println("----"+this.ID+"----");
        System.out.println("Destino: "+this.destino);
        System.out.println("Fecha: "+this.fecha);
        System.out.println("Precio: "+this.costo);
        System.out.println("N° asientos: "+this.num_asientos);
        System.out.println("---------------------------");
    }
    
    public Object[] toArray() {
        Object[] obj = new Object[6];
        obj[0] = this.ID;
        obj[1] = this.inicio;
        obj[2] = this.destino;
        obj[3] = this.fecha;
        obj[4] = this.costo;
        obj[5] = this.num_asientos;
        
        return obj;
    }
}
