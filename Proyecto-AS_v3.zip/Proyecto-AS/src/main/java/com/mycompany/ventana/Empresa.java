package com.mycompany.ventana;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Empresa {
    private ListaCiudades listaCiudades;
    private MapaCiudades mapaCiudades;
   
    public Empresa(){
       this.listaCiudades = new ListaCiudades();
       this.mapaCiudades = new MapaCiudades(); 
    }
    
    //Lectura
    public BufferedReader createLector () throws IOException {
        BufferedReader input = new BufferedReader (new InputStreamReader(System.in));
        return input;
    }
    
    public void run (Empresa e) throws IOException {
        e.importar();
        InterfazPrincipal.mainWindow(e);
    }
    
    public int size () {
        return listaCiudades.size();
    }
    
    public Ciudad getCiudad (int index) {
        return listaCiudades.get_i(index);
    }
    
    public Ciudad getCiudad (String city) throws UnvalidCityException {
        try {
            return mapaCiudades.get_ciudad(city);
        } catch (UnvalidCityException ex) {
            throw new UnvalidCityException();
        }
    }
    
    public void addCity (String text) throws UnvalidNameException {
        //Verificar Excepción
        if (text.length() > 12 || text.length() < 3) {
            throw new UnvalidNameException(); 
        }
        //Crear nueva Ciudad a partir del texto
        Ciudad city = new Ciudad (text);
        //Agregar ciudad a Lista y Mapa de Ciudades.
        listaCiudades.addCity(city);
        mapaCiudades.addCity(text, city);
    }
    
    public void deleteCity (int index) throws EmptyObjectException {
        //Verificar Excepción
        if (listaCiudades.size() == 0) {
            throw new EmptyObjectException(); 
        }
        //Agregar ciudad a Lista y Mapa de Ciudades.
        Ciudad cityAux = listaCiudades.get_i(index);
        listaCiudades.deleteCity(index);
        mapaCiudades.deleteCity(cityAux.get_nombre(), cityAux);
    }
            
    public void importar() throws FileNotFoundException, IOException{
        String lib = "Libro1.txt";
        BufferedReader lector = new BufferedReader(new FileReader(lib));
        
        String line = null;
        /*Importar lo que esta en el archivo Libro1.txt*/
        while((line = lector.readLine()) != null){
            String[] arr = line.split(";");
            
            Ciudad c = new Ciudad(arr[0]);
            listaCiudades.setObject(c);
        }
        
        lector.close();
        /*Recorrer las ciudades e ir diciendo que importen sus buses*/
        for(int i = 0; i < listaCiudades.size();i++){
            Ciudad c = listaCiudades.get_i(i);
            c.importar();
            listaCiudades.setObjectI(i,c);
            mapaCiudades.setObject(c.get_nombre(),c);
        }
        
    }
    
    public void depurar () {
        listaCiudades.clean();
        mapaCiudades.clean();
    }
    
    public void exportar() throws FileNotFoundException, IOException{
        /*Separar los nombres para borrar los archivos*/
        String[] val = obtenerNombres().split(";");
        eliminarFicheros(val);
        escribirEnNuevosArchivos();
        
    }
    
    private void escribirEnNuevosArchivos() throws IOException{
        String aux = null;
        for(int i = 0; i < listaCiudades.size();i++){
            /*Crear archivos*/
            File f = null;
            FileWriter w = null;
            BufferedWriter bw = null;
            PrintWriter wr = null;
            
            /*Obtener ciudades*/
            Ciudad c = (Ciudad)listaCiudades.get_i(i);
            aux = aux+";"+c.get_nombre();
            
            /*Inicializacion*/
            f = new File(c.get_nombre()+".txt");
            w = new FileWriter(f);
            bw = new BufferedWriter(w);
            wr = new PrintWriter(bw);
            
            
            
            /*Escribir la lista de buses en el archivo*/
            for(int k = 0;k<c.getSizeArrayList();k++){
                Bus b = c.get_bus(k);
                String val = b.get_ID()+";"+b.get_inicio()+";"+b.get_destino()+";"+b.get_fecha()+";"+b.get_costo()+";"+b.get_numAsientos()+"\n";
                wr.write(val);
            }
            
            
            bw.close();
            wr.close();  
            
        }
        File f = null;
        FileWriter w = null;
        BufferedWriter bw = null;
        PrintWriter wr = null;
        
        
        f = new File("Libro1.txt");
        w = new FileWriter(f);
        bw = new BufferedWriter(w);
        wr = new PrintWriter(bw);
        String[] arr = aux.split(";");
        for(int j = 1;j < arr.length;j++){
            wr.write(arr[j]+"\n");
        }
        
        
        bw.close();
        wr.close(); 
    }
    
    private String obtenerNombres() throws FileNotFoundException, IOException{
        /*Leer archivos existentes para borrarlos y crearlos de nuevo*/
        String lib = "Libro1.txt";
        BufferedReader lector = new BufferedReader(new FileReader(lib));
        String line = null;
        
        String aux = null;
        /*Importar lo que esta en el archivo Libro1.txt*/
        while((line = lector.readLine()) != null){
            String[] arr = line.split(";");
            aux = aux+";"+ arr[0];
        }
        lector.close();
        
        return aux;
    }
    
    private void eliminarFicheros(String[]val){
        
        try{
            for(int i = 1; i < val.length; i++){
                File archivo = new File(val[i]+".txt");

                boolean estatus = archivo.delete();

                if (!estatus) {
                    System.out.println("Error no se ha podido eliminar el  archivo");
                }else{
                    System.out.println("Se ha eliminado el archivo exitosamente");
                }
            }
        }catch(Exception e){
           System.out.println(e);
        }
    }
    
}
