
package com.mycompany.ventana;

public class EmptyObjectException extends Exception {
    public EmptyObjectException (){
        super("El objeto está vacío.");
    }
}
