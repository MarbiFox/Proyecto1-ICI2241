
package com.mycompany.ventana;


public class MainClass {
    public static void main (String [] args) {
        System.out.println("Ola que ase...");
        VentanaInicial.mainVentana();
    }
    
    public static void printAlgo() {
        System.out.println("Print");
    }
    
    
    
    public static void initializeMenu(int x, int y) {
        System.out.println("Menú");
        VentanaInicial screenMenu = new VentanaInicial();
        screenMenu.setDefaultCloseOperation(VentanaInicial.DISPOSE_ON_CLOSE);
        screenMenu.setSize(800, 500);
        screenMenu.setLocationRelativeTo(null);

        screenMenu.setVisible(true);
        screenMenu.setLocation(x, y);
        System.out.println("x:" + x + " y:" + y);
        
    }
    
}
