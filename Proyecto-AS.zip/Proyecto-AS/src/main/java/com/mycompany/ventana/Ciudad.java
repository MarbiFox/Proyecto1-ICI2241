package com.mycompany.ventana;

import java.io.FileNotFoundException;

public class Ciudad {
    //Variables de instancia
    
    private String nombre; //ciudad de partida
    private ListaBuses buses;
    
    //----Constructor----  
    /*Crea una ciudad con un nombre e inicializa el ArrayList*/
    public Ciudad(String n){
        nombre = n;
        buses = new ListaBuses();
    }
       
    //----Metodos----
    
    //----Setter----
    /*Modifica el nombre de la ciudad*/
    public void set_nombre(String n){
        this.nombre = n;
    }
    
    //----Getter----
    /*Obtiene el nombre de la ciudad*/
    public String get_nombre(){
        return this.nombre;
    }
    
    public int getSizeArrayList(){
        return this.buses.get_size();
    }
    
    public Bus get_bus(int i){
        return (Bus)buses.get_i(i);
    }
    
       
    /*Obtiene un bus de la ciudad a partir de un nombre*/
    public Bus obtenerBus(String var){
        int i;
        for(i = 0;i < buses.get_size();i++){
            Bus datos = buses.get_getter(i);
            if(datos.get_nombre().equals(var)){
                return buses.get_getter(i);
            }
        }
        return null;
    }
    
    /*obtiene un nuevo elemento a partir de un nombre y una fecha*/
    public Bus obtenerBus(String nombre, String fecha){
        int i;
        for(i = 0;i < buses.get_size();i++){
            Bus datos = buses.get_getter(i);
            if(datos.get_nombre().equals(nombre) && datos.get_fecha().equals(fecha)){
                buses.get_getter(i);
            }
        }
        return null;
    }
    
    public void importar() throws FileNotFoundException{
        buses.importar(this.nombre);
    }
    
}
