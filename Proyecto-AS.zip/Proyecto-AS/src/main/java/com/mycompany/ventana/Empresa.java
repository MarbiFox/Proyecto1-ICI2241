package com.mycompany.ventana;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Empresa {
    private ListaCiudades listaCiudades;
    private MapaCiudades mapaCiudades;
   
    public Empresa(){
       this.listaCiudades = new ListaCiudades();
       this.mapaCiudades = new MapaCiudades(); 
    }
    
    //Lectura
    public BufferedReader createLector () throws IOException {
        BufferedReader input = new BufferedReader (new InputStreamReader(System.in));
        return input;
    }
    
    public void run () {
        InterfazPrincipal.mainWindow();
    }
    
    public void importar() throws FileNotFoundException, IOException{
        String lib = "Libro1.txt";
        BufferedReader lector = new BufferedReader(new FileReader(lib));
        
        String line = null;
        /*Importar lo que esta en el archivo Libro1.txt*/
        while((line = lector.readLine()) != null){
            String[] arr = line.split(";");
            
            Ciudad c = new Ciudad(arr[0]);
            listaCiudades.setObject(c);
        }
        
        lector.close();
        /*Recorrer las ciudades e ir diciendo que importen sus buses*/
        for(int i = 0; i < listaCiudades.size();i++){
            Ciudad c = listaCiudades.get_i(i);
            c.importar();
            listaCiudades.setObjectI(i,c);
            mapaCiudades.setObject(c.get_nombre(),c);
        }
        
    }
    
    //Función agregarBus
    /*
    public void agregarBus()throws IOException{
        
        BufferedReader lector = createLector();
        
        System.out.println("Ingrese la ciudad a agregar el bus: ");
        
        String nombreCiudad = lector.readLine();

        Ciudad dato = (Ciudad)mapaCiudades.get_ciudad(nombreCiudad);
        if (dato == null){
            System.out.println("[Ciudad no encontrada en el sistema]");
            return;
        }

        System.out.println("Ingrese el nombre del bus: ");
        String nombreBus = lector.readLine();
        
        System.out.println("Ingrese Destino del bus: ");
        String destino = lector.readLine();
        
        System.out.println("Ingrese la fecha del bus: ");
        String fechaBus = lector.readLine();
        
        System.out.println("Ingrese el costo del pasaje: ");
        int costoBus = Integer.parseInt(lector.readLine());
        
        System.out.println("Ingrese el numero de asientos: ");
        int asientosBus = Integer.parseInt(lector.readLine());
         
        Bus bus = new Bus(nombreBus,fechaBus,destino,costoBus,asientosBus);
        
        //agregar bus a ciudad
        //dato.agregarBus(bus);
        System.out.println("[Bus agregado]\n");
    }
    */
    
    /*
    
    public void importar() throws FileNotFoundException, IOException{
        String lib = "C:\\Users\\thoma\\OneDrive\\Documentos\\NetBeansProjects\\MainProgram\\Libro1.txt";
        BufferedReader lector = new BufferedReader(new FileReader(lib));
        
        String line = null;
        
        while((line = lector.readLine()) != null){
            String[] arr = line.split(";");
            
            Ciudad c = new Ciudad(arr[0]);
            listaCiudades.setObject(c);
        }
        
        
        for(int i = 0; i < listaCiudades.size();i++){
            Ciudad c = (Ciudad) listaCiudades.get_i(i);
            c.importar();
            listaCiudades.setObjectI(i,c);
            mapaCiudades.setObject(c.get_nombre(),c);
        }
        lector.close();
    }
    
    /*
    private Ciudad import_city(Ciudad n,BufferedReader lector) throws FileNotFoundException, IOException{
        
        try{
            String city = "\\"+n.get_nombre()+".txt";
            String temp = "C:\\Users\\thoma\\OneDrive\\Documentos\\NetBeansProjects\\MainProgram\\Ciudades"+city;
            lector = new BufferedReader(new FileReader(temp));
            
            String line;
                
            while((line = lector.readLine())!= null){
                String[] arr = line.split(";");
                Bus b = new Bus(arr[0],arr[1],arr[2],Integer.parseInt(arr[3]),Integer.parseInt(arr[4]));
                n.agregarBus(b);
            }
            
            return n;
        }catch(IOException c){
            c.printStackTrace();
            return null;
        }
    }*/
}
