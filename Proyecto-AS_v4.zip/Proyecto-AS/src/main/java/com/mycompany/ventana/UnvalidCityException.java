
package com.mycompany.ventana;

/**
 *
 * @author benja
 */
public class UnvalidCityException extends Exception {
    public UnvalidCityException() {
        super("Ciudad no encontrada.");
    }
}
