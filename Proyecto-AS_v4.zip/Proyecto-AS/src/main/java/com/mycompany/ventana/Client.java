
package com.mycompany.ventana;

public class Client extends User{
    private int rut;

    public Client(String nombre,String mail,int numero,int rut){
        super(nombre,mail,numero);
        this.rut = rut;
    }
    
    public int getRut() {
        return rut;
    }

    public void setRut(int rut) {
        this.rut = rut;
    }
    
    public boolean acceder(String nombre,String mail,int numero,int rut){
        if(!getNombre().equals(nombre)||!getMail().equals(mail)||
                getNumero()!=numero||this.rut!=rut){
            return false;
        }
        return true;
    }
    @Override
    public void vaciarDatos(){
        setNombre(null);
        setMail(null);
        setNumero(0);
        this.rut = 0;
    }
}
