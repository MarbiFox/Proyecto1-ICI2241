
package com.mycompany.ventana;
import java.io.IOException;


public class MainClass {
    public static void main (String [] args) throws IOException {
        ListUser list = new ListUser ();
        list.importar();
        System.out.println("Ola que ase...");
        //Iniciar Empresa
        Empresa e = new Empresa ();
        e.run(e, list);
    }
}
