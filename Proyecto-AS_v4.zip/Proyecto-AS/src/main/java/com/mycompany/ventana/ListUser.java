
package com.mycompany.ventana;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;

public class ListUser {
    private HashMap <String,Administrator> mapaAdmi;
    private HashMap <Integer,Client> mapaClient;

    public ListUser() {
        this.mapaAdmi = new HashMap<String,Administrator>();
        this.mapaClient = new HashMap<Integer,Client>();
    }
    
    public Administrator getAdmi(String n){
        return this.mapaAdmi.get(n);
    }
    
    public Client getClient(int i){
        return this.mapaClient.get(i);
    }
    
    public void addAdmi(String n, Administrator aux){
        mapaAdmi.put(n, aux);
    }
    
    public void addClient(int rut,Client aux){
        mapaClient.put(rut, aux);
    }
    
    
    public void importar() throws FileNotFoundException, IOException{
        String lib = "InformacionAdministrador.txt;InformacionCliente.txt";
        String []aux = lib.split(";");
        
        BufferedReader lector = new BufferedReader(new FileReader(aux[0]));
        String line = null;
        /*Importar lo que esta en el archivo Libro1.txt*/
        while((line = lector.readLine()) != null){
            String[] arr = line.split(";");
            Administrator admi = new Administrator(arr[0],arr[2],Integer.parseInt(arr[1]),arr[3]);
            System.out.println("Ola que ase..");
            addAdmi(arr[0], admi);
        }
        lector.close();
        
        BufferedReader lector1 = new BufferedReader(new FileReader(aux[1]));
        String line1 = null;
        /*Importar lo que esta en el archivo Libro1.txt*/
        while((line1 = lector1.readLine()) != null){
            String[] arr = line1.split(";");
            Client client = new Client(arr[0],arr[2],Integer.parseInt(arr[1]),Integer.parseInt(arr[3]));
            addClient(Integer.parseInt(arr[3]), client);
        }
        lector.close();
    }
    
    public void removeData(){
        mapaAdmi.clear();
        mapaClient.clear();
    }
    
}
