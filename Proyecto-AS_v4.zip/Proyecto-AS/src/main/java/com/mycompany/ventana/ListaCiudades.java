package com.mycompany.ventana;
import javax.swing.DefaultListModel;

import java.util.ArrayList;

public class ListaCiudades {
    private ArrayList <Ciudad> listaCiudades;
    
    public ListaCiudades(){
        listaCiudades = new ArrayList<Ciudad>();
    }
    
    public Ciudad get_i(int i){
        return listaCiudades.get(i);
    }
    
    public int size(){
        return listaCiudades.size();
    }
    
    public void addCity (Ciudad city) {
        listaCiudades.add(city);
    }
    
    public void deleteCity (int index) {
        listaCiudades.remove(index);
    }
    
    public void clean () {
        listaCiudades.clear();
    }
    
    public void setObjectI(int i,Ciudad c){
        listaCiudades.remove(i);
        listaCiudades.add(i, c);
    }
    
    public void setObject(Ciudad c){
        listaCiudades.add(c);
    }
}
