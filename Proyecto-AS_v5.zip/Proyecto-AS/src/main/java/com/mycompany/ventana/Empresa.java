package com.mycompany.ventana;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

public class Empresa {
    //Atributos Generales.
    private ListaCiudades listaCiudades;
    private MapaCiudades mapaCiudades;
    
    /*---Constructor---*/
    public Empresa(){
       this.listaCiudades = new ListaCiudades();
       this.mapaCiudades = new MapaCiudades(); 
    }
    
    //Lectura de Datos
    public BufferedReader createLector () throws IOException {
        BufferedReader input = new BufferedReader (new InputStreamReader(System.in));
        return input;
    }
    
    //Iniciar aplicación
    public void run (Empresa e, ListUser l) throws IOException {
        e.importar();
        InterfazPrincipal.mainWindow(e, l);
    }
    
    //Obtener tamaño de la lista de Ciudades.
    public int size () {
        return listaCiudades.size();
    }
    
    //Obtener una ciudad de la listaCiudades.
    public Ciudad getCiudad (int index) {
        return listaCiudades.get_i(index);
    }
    
    //Obtener una ciudad del mapaCiudades.
    public Ciudad getCiudad (String name) throws UnvalidCityException {
        try {
            return mapaCiudades.get_ciudad(name);
        } catch (UnvalidCityException ex) {
            throw new UnvalidCityException();
        }
    }
    
    //Agregar una ciudad a la Lista y Mapa de ciudades.
    public void addCity (String text) throws UnvalidNameException {
        //Verificar Excepción
        if (text.length() > 12 || text.length() < 3) {
            throw new UnvalidNameException(); 
        }
        //Crear nueva Ciudad a partir del texto
        Ciudad city = new Ciudad (text);
        ///Eliminar de Lista y Mapa.
        listaCiudades.addCity(city);
        mapaCiudades.addCity(text, city);
    }
    //Eliminar una ciudad de la Lista y Mapa de ciudades.
    public void deleteCity (int index) throws EmptyObjectException {
        //Verificar Excepción
        if (listaCiudades.size() == 0) {
            throw new EmptyObjectException(); 
        }
        //Eliminar de Lista y Mapa.
        Ciudad cityAux = listaCiudades.get_i(index);
        listaCiudades.deleteCity(index);
        mapaCiudades.deleteCity(cityAux.get_nombre(), cityAux);
    }
    
    //Importa datos.
    public void importar() throws FileNotFoundException, IOException{
        String lib = "Libro1.txt";
        BufferedReader lector = new BufferedReader(new FileReader(lib));
        
        String line = null;
        /*Importar lo que esta en el archivo Libro1.txt*/
        while((line = lector.readLine()) != null){
            String[] arr = line.split(";");
            
            Ciudad c = new Ciudad(arr[0]);
            listaCiudades.setObject(c);
        }
        
        lector.close();
        /*Recorrer las ciudades e ir diciendo que importen sus buses*/
        for(int i = 0; i < listaCiudades.size();i++){
            Ciudad c = listaCiudades.get_i(i);
            c.importar();
            listaCiudades.setObjectI(i,c);
            mapaCiudades.setObject(c.get_nombre(),c);
        }
        
    }
    
    //Limpia la Lista y Mapa de Ciudades para evitar datos repetidos.
    public void depurar () {
        listaCiudades.clean();
        mapaCiudades.clean();
    }
    
    //Exporta Datos.
    public void exportar() throws FileNotFoundException, IOException{
        /*Separar los nombres para borrar los archivos*/
        String[] val = obtenerNombres().split(";");
        eliminarFicheros(val);
        escribirEnNuevosArchivos();
        
    }
    
    //Crear un nuevo archivo con el nuevo contenido a escribir.
    private void escribirEnNuevosArchivos() throws IOException{
        String aux = null;
        for(int i = 0; i < listaCiudades.size();i++){
            /*Crear archivos*/
            File f = null;
            FileWriter w = null;
            BufferedWriter bw = null;
            PrintWriter wr = null;
            
            /*Obtener ciudades*/
            Ciudad c = (Ciudad)listaCiudades.get_i(i);
            aux = aux+";"+c.get_nombre();
            
            /*Inicializacion*/
            f = new File(c.get_nombre()+".txt");
            w = new FileWriter(f);
            bw = new BufferedWriter(w);
            wr = new PrintWriter(bw);
            
            /*Escribir la lista de buses en el archivo*/
            for(int k = 0;k<c.getSizeArrayList();k++){
                Bus b = c.get_bus(k);
                String val = b.get_ID()+";"+b.get_inicio()+";"+b.get_destino()+";"+b.get_fecha()+";"+b.get_costo()+";"+b.get_numAsientos()+"\n";
                wr.write(val);
            }
            
            /*Cerrar los archivos*/
            bw.close();
            wr.close();  
        }
        
        /*Crear Archivo Libro1*/
        File f = null;
        FileWriter w = null;
        BufferedWriter bw = null;
        PrintWriter wr = null;
        
        /*Generar datos para el archivo*/
        f = new File("Libro1.txt");
        w = new FileWriter(f);
        bw = new BufferedWriter(w);
        wr = new PrintWriter(bw);
        String[] arr = aux.split(";");
        for(int j = 1;j < arr.length;j++){
            wr.write(arr[j]+"\n");
        }
        
        /*Cerrar*/
        bw.close();
        wr.close(); 
    }
    
    //Abre el archivo general y obtiene una cadena con los nombres de las ciudades.
    private String obtenerNombres() throws FileNotFoundException, IOException{
        /*Leer archivos existentes para borrarlos y crearlos de nuevo*/
        String lib = "Libro1.txt";
        BufferedReader lector = new BufferedReader(new FileReader(lib));
        String line = null;
        
        String aux = null;
        /*Importar lo que esta en el archivo Libro1.txt*/
        while((line = lector.readLine()) != null){
            String[] arr = line.split(";");
            aux = aux+";"+ arr[0];
        }
        lector.close();
        
        return aux;
    }
    
    //Elimina los ficheros del arreglo de valores.
    private void eliminarFicheros(String[]val){
        //Recorrer y Eliminar.
        try{
            for(int i = 1; i < val.length; i++){
                File archivo = new File(val[i]+".txt");
                archivo.delete();
            }
        }catch(Exception e){
           System.out.println(e);
        }
    }
    
}
