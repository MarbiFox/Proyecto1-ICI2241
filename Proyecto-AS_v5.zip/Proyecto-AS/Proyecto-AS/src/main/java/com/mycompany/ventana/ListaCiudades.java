package com.mycompany.ventana;
import javax.swing.DefaultListModel;

import java.util.ArrayList;

public class ListaCiudades {
    private static ArrayList <Ciudad> listaCiudades;
    
    public ListaCiudades(){
        listaCiudades = new ArrayList();
    }
    
    public static Ciudad get_i(int i){
        return listaCiudades.get(i);
    }
    
    public static int size(){
        return listaCiudades.size();
    }
    
    public static void addCity (String text) throws UnvalidNameException {
        //Verificar Excepción
        if (text.length() > 12 || text.length() < 3) {
            throw new UnvalidNameException(); 
        }
        //Crear nueva Ciudad a partir del texto
        Ciudad city = new Ciudad (text);
        //Agregar ciudad a Lista y Mapa de Ciudades.
        listaCiudades.add(city);
    }
    
    public static void deleteCity (int index) throws EmptyObjectException {
        //Verificar Excepción
        if (listaCiudades.isEmpty()) {
            throw new EmptyObjectException(); 
        }
        //Agregar ciudad a Lista y Mapa de Ciudades.
        listaCiudades.remove(index);
    }
    
    public static void setObjectI(int i,Ciudad c){
        listaCiudades.remove(i);
        listaCiudades.add(i, c);
    }
    
    public static void setObject(Ciudad c){
        listaCiudades.add(c);
    }
}
