package com.mycompany.ventana;

import java.util.HashMap;

public class MapaCiudades {
    private static HashMap <String,Ciudad> mapaCiudades;
    
    public MapaCiudades(){
        mapaCiudades = new HashMap();
    }
    
    public Ciudad get_ciudad(String name){
        if (mapaCiudades.get(name) != null){
            return mapaCiudades.get(name);
        }
        return null;
    }
    
    public void setObject(String n,Ciudad temp){
        mapaCiudades.put(n, temp);
    }
    
    public Ciudad searchObject(String n){
        return mapaCiudades.get(n);
    }
    
    public static void addCity (String text) {
        //Crear nueva Ciudad a partir del texto
        Ciudad city = new Ciudad (text);
        //Agregar ciudad a Mapa de Ciudades.
        mapaCiudades.put(text, city);
    }
    
    public static void deleteCity (String text) throws EmptyObjectException {
        //Buscar Ciudad
        Ciudad city = mapaCiudades.get(text);
        //Eliminar Ciudad.
        mapaCiudades.remove(text, city);
    }
    
}